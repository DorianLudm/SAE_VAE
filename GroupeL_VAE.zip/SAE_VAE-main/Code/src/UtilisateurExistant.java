public class UtilisateurExistant extends Exception {
    
}