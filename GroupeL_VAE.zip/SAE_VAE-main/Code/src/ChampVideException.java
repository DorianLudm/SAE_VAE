public class ChampVideException extends Exception{
    
}
